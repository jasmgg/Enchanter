/**
 * Enchanter — Phase 1 seed
 * Seeds 3 test sites: coastal, landlocked, edge case (site on coastal/landlocked boundary)
 *
 * Run: node db/seed.js
 */
require('dotenv').config();
const pool = require('./pool');

// Three sites from the MVP set, covering coastal, landlocked, and an
// edge-case site (Westminster Abbey — high-pressure coastal, which is the
// outlier in the MVP list and useful to test coefficient polarity).
const SITES = [
  {
    name: 'Tintagel',
    latitude: 50.6660,
    longitude: -4.7630,
    radius_metres: 200,
    site_type: 'coastal',
    effect_description:
      'Beams of light descend from the sky to burn any undead beings for an initial burst and damage over time.',
    spell_name: 'Smite',
    lore_note:
      'The cliff-top ruins carry memories of a kingdom that may never have been. The sea below never calms.',
    region: 'Cornwall',
    affinity_lunar: 'light',
    affinity_geo: 'low_pressure',
    affinity_tod: 'light',
    affinity_season: 'summer',
  },
  {
    name: 'Abney Park Cemetery',
    latitude: 51.5636,
    longitude: -0.0784,
    radius_metres: 200,
    site_type: 'landlocked',
    effect_description:
      'The earth splits and a skeletal warrior claws free, bound to serve the caster for the spell\'s duration.',
    spell_name: 'Summon Skeleton',
    lore_note:
      'A Victorian garden cemetery that became a nature reserve. The memorials lean. The trees have swallowed the paths.',
    region: 'London',
    affinity_lunar: 'dark',
    affinity_geo: 'calm_solar',
    affinity_tod: 'dark',
    affinity_season: 'winter',
  },
  {
    // Edge case: high-pressure coastal — tests the inverse geo coefficient polarity
    name: 'Westminster Abbey',
    latitude: 51.4994,
    longitude: -0.1273,
    radius_metres: 200,
    site_type: 'coastal',
    effect_description:
      'A warm pulse of restorative light flows from the caster into a touched ally, recovering lost vitality. Cannot target the caster.',
    spell_name: 'Heal Other',
    lore_note:
      'The coronation church. Consecrated ground layered so deep that history becomes geology.',
    region: 'London',
    affinity_lunar: 'light',
    affinity_geo: 'high_pressure',  // <-- edge case: coastal but high-pressure affinity
    affinity_tod: 'light',
    affinity_season: 'summer',
  },
];

async function seed() {
  const client = await pool.connect();
  try {
    console.log('Seeding test sites…');

    for (const site of SITES) {
      const result = await client.query(
        `INSERT INTO sites (
          name, latitude, longitude, radius_metres, site_type,
          effect_description, spell_name, lore_note, region,
          affinity_lunar, affinity_geo, affinity_tod, affinity_season
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
        ON CONFLICT DO NOTHING
        RETURNING id, name`,
        [
          site.name, site.latitude, site.longitude, site.radius_metres,
          site.site_type, site.effect_description, site.spell_name,
          site.lore_note, site.region,
          site.affinity_lunar, site.affinity_geo, site.affinity_tod,
          site.affinity_season,
        ]
      );

      if (result.rows.length > 0) {
        console.log(`  ✓ Seeded: ${result.rows[0].name} (${result.rows[0].id})`);
      } else {
        console.log(`  – Skipped (already exists): ${site.name}`);
      }
    }

    console.log('Seed complete.');
  } catch (err) {
    console.error('Seed failed:', err);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
